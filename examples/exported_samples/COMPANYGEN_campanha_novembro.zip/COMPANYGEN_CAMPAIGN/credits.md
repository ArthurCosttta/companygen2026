# Créditos e Licenças — KU Confecções
Campanha: Nova Coleção
Data: 07/11/2026

## Fotografias Utilizadas
- **img_001**: Kumail_Kazmi_Blue_BG_Profile - Kumail_Kazmi_Profile — Foto por [syedkumailhaiderkazmi](https://www.flickr.com/photos/192304962@N03/55313156752). Licença: PDM 1.0
- **img_002**: Clothing Top — Foto por [Kristin Hardwick](https://stocksnap.io/photo/clothing-top-TEFSYENORD). Licença: CC0 1.0
- **img_003**: Miss Betty McParland (1936) Spencer — Foto por [museumofnewzealand](https://www.rawpixel.com/image/9900833/miss-betty-mcparland-1936-spencer-digby-studios). Licença: CC0 1.0
- **img_004**: Miss D Lodge (1930s) Spencer — Foto por [museumofnewzealand](https://www.rawpixel.com/image/9889228/miss-lodge-1930s-spencer-digby-studios). Licença: CC0 1.0
- **img_005**: “Green Goodness, Veggie Delight” — Foto por [Rob Olivera](https://www.flickr.com/photos/190269253@N07/53841573909). Licença: CC BY 2.0
- **img_006**: 20240705 Talismanic shirt detail — Foto por [schizoform](https://www.flickr.com/photos/84175980@N00/53863913656). Licença: CC BY 2.0
- **img_007**: 2022-10-29_11-21-23_ILCE-6500_DSC19330_Kiri_DxO — Foto por [miguel.discart](https://www.flickr.com/photos/69506664@N06/52541189581). Licença: CC BY-SA 2.0
- **img_008**: Clothing Shoes — Foto por [Kristin Hardwick](https://stocksnap.io/photo/clothing-shoes-ZDVS9WWEL1). Licença: CC0 1.0
- **img_009**: Asian Amateur Tiffany - Sexy Bent Over Bra and Jeans Tease — Foto por [tiffanyartistmodel](https://www.flickr.com/photos/194724223@N02/55232598791). Licença: CC0 1.0
- **img_010**: Cup Flat lay Clips — Foto por [Autor não informado](https://www.rawpixel.com/image/5967419/cup-flat-lay-clips). Licença: CC0 1.0
- **img_011**: Fashion Friday — Foto por [David Jackmanson](https://www.flickr.com/photos/58301516@N00/52539602130). Licença: CC BY 2.0
- **img_012**: Improv show — Foto por [ospp0](https://www.flickr.com/photos/196301716@N03/52693351895). Licença: CC0 1.0
- **img_013**: Men's winter outfit — Foto por [Rydale Country Clothing](https://www.flickr.com/photos/182435424@N02/51616923362). Licença: CC BY 2.0
- **img_014**: Asian Amateur Tiffany - Casual Cardigan and Crossed Arms Outdoor Portrait — Foto por [tiffanyartistmodel](https://www.flickr.com/photos/194724223@N02/55233214359). Licença: CC0 1.0
- **img_015**: Miss M Walsh (11 May — Foto por [museumofnewzealand](https://www.rawpixel.com/image/9900633/miss-walsh-11-may-1936-spencer-digby-studios). Licença: CC0 1.0
- **img_016**: Prehistorical goddess of fertility with large hips holding a bison horn, from Laussel, France, ca. 25,000-20,000 BC. carved translucent blue quartz, 1’ 6' high.high quality catalog studio photo, soft lighting — Foto por [fdecomite](https://www.flickr.com/photos/21649179@N00/52268805133). Licença: CC BY 2.0
- **img_017**: Asian Amateur Tiffany - Sexy Before and After Selfies and Makeup Close-Up — Foto por [tiffanyartistmodel](https://www.flickr.com/photos/194724223@N02/55232059322). Licença: CC0 1.0
- **img_018**: 2022-03-05_11-24-31_ILCE-7C_DSCAJ8862_DxO — Foto por [miguel.discart](https://www.flickr.com/photos/69506664@N06/51959704573). Licença: CC BY-SA 2.0
- **img_019**: Street Jeans full combo Textures JPG Outfits ( 4 Top + 4 Jeans ) Sis3d — Foto por [namminliz](https://www.flickr.com/photos/57221465@N04/40100808034). Licença: CC BY 2.0
- **img_020**: Iret-horru with Osiris ca. 610-595 BCE (Late Period, 26th dynasty) — Foto por [museado](https://www.flickr.com/photos/200781279@N05/53880044128). Licença: CC0 1.0

## Nota Legal
Imagens autorizadas para uso comercial e modificações obtidas através de APIs públicas com licenças verificadas.