# KU Confecções — Studio de Posts
Campanha gerada pelo CompanyGen Post Studio.
- Total de posts: 2
- Total de slides: 10
- Resolução exata: 1080 × 1350 px (4:5)